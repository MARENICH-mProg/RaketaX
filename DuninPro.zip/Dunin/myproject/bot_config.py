from aiogram import Bot
from aiogram import F, Router, types
from aiogram.enums import ParseMode, ChatAction
from aiogram.client.default import DefaultBotProperties



bot = Bot(token='your token TG bot')
