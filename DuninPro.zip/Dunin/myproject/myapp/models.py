from django.db import models

class User(models.Model):
    user_id = models.AutoField(primary_key=True)  # Автоматически увеличиваемый ID
    username = models.CharField(max_length=255, null=True, blank=True)  # Поле для имени пользователя, может быть NULL
    thread_id = models.CharField(max_length=255)                         # Поле для thread_id
    status = models.IntegerField(default=0)                              # Поле для статуса с дефолтным значением 0

    def __str__(self):
        return self.username if self.username else "Без имени"  # Возвращает имя пользователя или "Без имени" при отсутствии



class Assistant(models.Model):
    name = models.CharField(max_length=255, primary_key=True)        # Основной ключ, уникальное имя ассистента
    assistant_id = models.CharField(max_length=255)                  # Текстовое поле для ID ассистента
    description = models.TextField(null=True, blank=True)            # Поле для описания, может быть пустым

    def __str__(self):
        return self.name  # Возвращает имя ассистента в строковом представлении модели


class ChatMeta(models.Model):
    """
    Храним дополнительные метаданные о чате:
    - auto_flag (синий флажок) – ставится, если последнее сообщение от бота (нет ответа от пользователя).
    - manual_flag (красный флажок) – ставится вручную менеджером.
    """
    chat_id = models.BigIntegerField(unique=True)
    chat_name = models.CharField(max_length=255, blank=True)
    auto_flag = models.BooleanField(default=False)
    manual_flag = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.chat_name or f'Чат #{self.chat_id}'} (auto: {self.auto_flag}, manual: {self.manual_flag})"


class TelegramMessage(models.Model):
    chat_id = models.BigIntegerField()  # ID чата
    user_id = models.BigIntegerField()  # ID пользователя
    username = models.CharField(max_length=255, blank=True, null=True)  # Имя пользователя (может быть пустым)
    message_id = models.IntegerField()  # Уникальный ID сообщения в рамках чата
    text = models.TextField(blank=True, null=True)  # Текст сообщения
    message_type = models.CharField(max_length=50, default="text")  # Тип сообщения
    timestamp = models.DateTimeField()  # Время отправки сообщения

    # Поля для медиафайлов
    photo_file_id = models.CharField(max_length=255, blank=True, null=True)
    video_file_id = models.CharField(max_length=255, blank=True, null=True)
    document_file_id = models.CharField(max_length=255, blank=True, null=True)
    file_url = models.URLField(blank=True, null=True)

    def __str__(self):
        return f"Message {self.message_id} from user {self.user_id} in chat {self.chat_id}"