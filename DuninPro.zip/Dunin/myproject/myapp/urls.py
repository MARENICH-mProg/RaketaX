from django.urls import path
from . import views

urlpatterns = [
    path('', views.chat_view, name='chat_list'),
    path('chat/<int:chat_id>/', views.chat_view, name='chat_detail'),
    path('chat/<int:chat_id>/messages/', views.chat_messages, name='chat_messages'),
    path('search/', views.search_chats, name='search_chats'),
    path('chat/<int:chat_id>/send/', views.send_message, name='send_message'),
    path('get_latest_chats/', views.get_latest_chats, name='get_latest_chats'),
    path('toggle_auto_flag/', views.toggle_auto_flag, name='toggle_auto_flag'),
    path('toggle_manual_flag/', views.toggle_manual_flag, name='toggle_manual_flag'),

]
