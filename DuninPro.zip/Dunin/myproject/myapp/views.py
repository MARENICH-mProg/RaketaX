import asyncio
import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta

from django.db.models import Max, Q, Subquery, OuterRef
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.middleware.csrf import get_token
from django.contrib.auth.decorators import login_required
from django.utils import timezone
# Путь, если нужно
sys.path.append('/root/Dunin')  # /Users/matvejgorbunov/PycharmProjects/Dunin/Dunin   /root/Dunin

from .models import TelegramMessage, ChatMeta
from bot_config import bot
import app.database as db

logging.basicConfig(level=logging.DEBUG)

# Пул потоков для фоновых задач
executor = ThreadPoolExecutor(max_workers=5)


@login_required
def chat_view(request, chat_id=None):
    """
    Основная страница админки: список чатов (с чекбоксами) и выбранный чат.
    При открытии чата (chat_id) сбрасывается автофлаг.
    """

    if not request.user.is_authenticated:
        return redirect(f'/admin/login/?next={request.path}')
    last_messages = TelegramMessage.objects.filter(chat_id=OuterRef('chat_id')).order_by('-timestamp')
    chats = (
        TelegramMessage.objects
        .values('chat_id')
        .annotate(
            last_message_time=Max('timestamp'),
            last_message_text=Subquery(last_messages.values('text')[:1])
        )
        .order_by('-last_message_time')
    )

    chat_list = []
    for chat in chats:
        # Пропускаем чаты, в которых нет ни одного сообщения от пользователя
        other_user_message = (
            TelegramMessage.objects
            .filter(chat_id=chat['chat_id'])
            .exclude(username="OvmSales_bot")
            .order_by('timestamp')
            .first()
        )
        if not other_user_message:
            continue

        chat_name = other_user_message.username if other_user_message.username else f"Чат #{chat['chat_id']}"

        # Пытаемся получить сохранённое значение автофлага из ChatMeta
        try:
            meta = ChatMeta.objects.get(chat_id=chat['chat_id'])
            auto_flag = meta.auto_flag
            manual_flag = meta.manual_flag
        except ChatMeta.DoesNotExist:
            # Если записи нет, вычисляем автофлаг на основании последнего сообщения
            last_msg = TelegramMessage.objects.filter(chat_id=chat['chat_id']).order_by('-timestamp').first()
            auto_flag = True if last_msg and last_msg.username == "OvmSales_bot" else False
            manual_flag = False

        chat_list.append({
            'chat_id': chat['chat_id'],
            'chat_name': chat_name,
            'last_message': chat['last_message_text'] or 'Нет сообщений',
            'last_message_time': chat['last_message_time'],
            'auto_flag': auto_flag,
            'manual_flag': manual_flag,
        })

    # Если конкретный чат открыт, сбрасываем автофлаг (если нужно)
    # if chat_id is not None:
    #     meta, _ = ChatMeta.objects.get_or_create(chat_id=chat_id, defaults={'chat_name': f"Чат #{chat_id}"})
    #     if meta.auto_flag:
    #         meta.auto_flag = False
    #         meta.save()

    current_chat_name = ""
    message_data = []
    if chat_id is not None:
        messages = TelegramMessage.objects.filter(chat_id=chat_id).order_by('timestamp')
        current_chat_name = next(
            (chat['chat_name'] for chat in chat_list if chat['chat_id'] == chat_id),
            f'Чат #{chat_id}'
        )
        message_data = [
            {
                'sender_name': msg.username if msg.username else f'User {msg.user_id}',
                'text': msg.text,
                'timestamp': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'is_user': (msg.username != "OvmSales_bot")
            }
            for msg in messages
        ]

    context = {
        'chats': chat_list,
        'current_chat_id': chat_id,
        'current_chat_name': current_chat_name,
        'messages': message_data,
    }
    return render(request, 'myapp/index.html', context)


def chat_messages(request, chat_id):
    """Возвращает JSON с сообщениями для указанного чата."""
    if not request.user.is_authenticated:
        return redirect(f'/admin/login/?next={request.path}')

    chat_msgs = TelegramMessage.objects.filter(chat_id=chat_id).order_by('timestamp')
    messages = []
    for msg in chat_msgs:
        is_user = (msg.username != "OvmSales_bot")
        messages.append({
            'sender_name': msg.username if msg.username else f'User {msg.user_id}',
            'text': msg.text,
            'timestamp': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'is_user': is_user
        })
    return JsonResponse({'messages': messages})


from django.utils import timezone
from django.db.models import Max, Q
from django.http import JsonResponse
from datetime import datetime
from django.shortcuts import redirect
from .models import TelegramMessage, ChatMeta

def flag_matches(flag, auto_flag, manual_flag):
    """ Проверяет, соответствует ли чат заданному фильтру по флагам """
    if flag == "blue":
        return auto_flag and not manual_flag
    elif flag == "red":
        return manual_flag and not auto_flag
    elif flag == "both":
        return auto_flag and manual_flag
    elif flag == "any":
        return auto_flag or manual_flag
    elif flag == "no-read":
        return auto_flag
    return True  # Если флаг не указан, принимаем всё

def search_chats(request):
    """
    Фильтрация чатов:
      1) По пользовательскому запросу (query) – chat_id / text / username.
      2) По дате последнего сообщения (start_date, end_date).
      3) По флажкам (flag=blue/red/both/any).
      4) Исключает сообщения от бота "OvmSales_bot".
    """
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Unauthorized"}, status=401)

    try:
        query = request.GET.get('query', '').strip()
        start_date = request.GET.get('start_date', '').strip()
        end_date = request.GET.get('end_date', '').strip()
        flag = request.GET.get('flag', '').strip()  # Фильтр по флагам

        # Фильтрация по дате (преобразование в timezone-aware)
        def parse_date(date_str):
            if not date_str:
                return None
            try:
                dt = datetime.strptime(date_str, '%Y-%m-%d')
                return timezone.make_aware(dt) if timezone.is_naive(dt) else dt
            except ValueError:
                return None

        dt_start = parse_date(start_date)
        dt_end = parse_date(end_date)
        if dt_end:
            dt_end = dt_end.replace(hour=23, minute=59, second=59)  # Включить весь день

        # Запрос для поиска последних user-сообщений в каждом чате (исключая бота)
        last_user_messages_qs = (
            TelegramMessage.objects
            .exclude(username="OvmSales_bot")
            .values('chat_id')
            .annotate(last_msg_time=Max('timestamp'))
        )

        # Фильтрация по дате
        if dt_start:
            last_user_messages_qs = last_user_messages_qs.filter(last_msg_time__gte=dt_start)
        if dt_end:
            last_user_messages_qs = last_user_messages_qs.filter(last_msg_time__lte=dt_end)

        # Преобразуем QuerySet в словарь chat_id → last_msg_time
        chat_times = {item['chat_id']: item['last_msg_time'] for item in last_user_messages_qs}

        # Если есть поисковой запрос (query), фильтруем по chat_id, username, тексту
        if query:
            # Получаем ВСЕ сообщения, которые содержат `query`, сортируем по убыванию времени
            msgs_qs = TelegramMessage.objects.filter(
                Q(chat_id__icontains=query) |
                Q(username__icontains=query) |
                Q(text__icontains=query)
            ).order_by('-timestamp')

            chat_data = {}

            # Находим самое позднее сообщение, СОДЕРЖАЩЕЕ `query`, для каждого `chat_id`
            for msg in msgs_qs:
                if msg.chat_id not in chat_data:
                    chat_data[msg.chat_id] = msg  # Берём самое позднее сообщение, соответствующее запросу

            results = []
            for chat_id, msg in chat_data.items():
                meta = ChatMeta.objects.filter(chat_id=chat_id).first()
                auto_flag = meta.auto_flag if meta else False
                manual_flag = meta.manual_flag if meta else False

                if not flag_matches(flag, auto_flag, manual_flag):
                    continue

                results.append({
                    'chat_id': chat_id,
                    'chat_name': msg.username or f"Чат #{chat_id}",
                    'last_message': msg.text or "Нет сообщений",
                    'last_message_time': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'auto_flag': auto_flag,
                    'manual_flag': manual_flag,
                })

            return JsonResponse({'chats': results})
        # Если нет query, получаем последние сообщения из chat_times
        chat_ids = list(chat_times.keys())
        metas = ChatMeta.objects.filter(chat_id__in=chat_ids)
        meta_dict = {m.chat_id: m for m in metas}

        tolerance = timedelta(seconds=1)  # Учитываем расхождение по микросекундам
        last_messages = {}
        for chat_id, last_time in chat_times.items():
            msg = (TelegramMessage.objects
                   .exclude(username="OvmSales_bot")
                   .filter(chat_id=chat_id,
                           timestamp__gte=last_time - tolerance,
                           timestamp__lte=last_time + tolerance)
                   .order_by('-timestamp')
                   .first())
            if msg:
                last_messages[chat_id] = msg

        # Формируем итоговый результат
        results = []
        for chat_id, message in last_messages.items():
            auto_flag = meta_dict.get(chat_id, ChatMeta(chat_id=chat_id)).auto_flag
            manual_flag = meta_dict.get(chat_id, ChatMeta(chat_id=chat_id)).manual_flag

            if not flag_matches(flag, auto_flag, manual_flag):
                continue

            results.append({
                'chat_id': chat_id,
                'chat_name': message.username if message.username else f"Чат #{chat_id}",
                'last_message': message.text if message.text else "Нет сообщений",
                'last_message_time': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'auto_flag': auto_flag,
                'manual_flag': manual_flag,
            })

        return JsonResponse({'chats': results})

    except ValueError as e:
        return JsonResponse({"error": f"ValueError: {str(e)}"}, status=400)
    except Exception as e:
        return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)




async def send_bot_message(chat_id, message_text):
    """Asynchronous function to send a message through the bot."""
    try:
        mess = await bot.send_message(chat_id, message_text)
        logging.debug(f"Message sent to chat_id={chat_id} with text='{message_text}'")
        return mess
    except Exception as e:
        logging.error(f"Error sending message with bot: {e}")
    finally:
        # Close the bot's session to release the connection
        await bot.session.close()
        logging.debug("Bot session closed")


def send_message_in_background(chat_id, message_text):
    """Wrapper function to run the bot message sending in a separate thread."""
    mess = asyncio.run(send_bot_message(chat_id, message_text))
    return mess






def get_latest_chats(request):
    """
    Возвращает JSON со списком чатов для автообновления.
    Для каждого чата возвращается:
      - chat_id
      - chat_name (определяется по первому пользовательскому сообщению)
      - last_message_text (последнее сообщение)
      - last_message_time
      - auto_flag (значение из ChatMeta, если оно есть, иначе вычисляем на основе последнего сообщения)
      - manual_flag (из ChatMeta)
    """
    # Извлекаем последнее сообщение для каждого чата
    last_messages = TelegramMessage.objects.filter(chat_id=OuterRef('chat_id')).order_by('-timestamp')
    chats = (
        TelegramMessage.objects
        .values('chat_id')
        .annotate(
            last_message_time=Max('timestamp'),
            last_message_text=Subquery(last_messages.values('text')[:1])
        )
        .order_by('-last_message_time')
    )

    chat_data = []
    for chat in chats:
        # Пропускаем чаты, где нет пользовательских сообщений
        other_user_message = (
            TelegramMessage.objects
            .filter(chat_id=chat['chat_id'])
            .exclude(username="OvmSales_bot")
            .order_by('timestamp')
            .first()
        )
        if not other_user_message:
            continue

        chat_name = other_user_message.username if other_user_message.username else f"Чат #{chat['chat_id']}"

        # Пытаемся получить сохранённое значение автофлага из ChatMeta
        try:
            meta = ChatMeta.objects.get(chat_id=chat['chat_id'])
            auto_flag = meta.auto_flag
            manual_flag = meta.manual_flag
        except ChatMeta.DoesNotExist:
            # Если записи нет, вычисляем автофлаг по последнему сообщению (это редко, если у вас уже установлены данные)
            last_msg = TelegramMessage.objects.filter(chat_id=chat['chat_id']).order_by('-timestamp').first()
            auto_flag = True if last_msg and last_msg.username == "OvmSales_bot" else False
            manual_flag = False

        chat_data.append({
            'chat_id': chat['chat_id'],
            'chat_name': chat_name,
            'last_message': chat['last_message_text'] or 'Нет сообщений',
            'last_message_time': chat['last_message_time'].strftime('%Y-%m-%d %H:%M:%S') if chat['last_message_time'] else '',
            'auto_flag': auto_flag,
            'manual_flag': manual_flag,
        })

    return JsonResponse({'chats': chat_data})


def save_telegram_message(message):
    # Основные данные сообщения, общие для всех типов
    message_data = {
        'chat_id': message.chat.id,
        'user_id': message.from_user.id,
        'username': message.from_user.username,
        'message_id': message.message_id,
        'text': message.text if message.content_type == 'text' else None,
        'message_type': message.content_type,
        'timestamp': message.date,  # Используем message.date напрямую
        'photo_file_id': None,
        'video_file_id': None,
    }

    # Проверяем тип сообщения и добавляем нужный file_id, если это фото или видео
    if message.content_type == 'photo':
        # Сохраняем среднее по качеству фото
        mid_photo = message.photo[len(message.photo) // 2]
        message_data['photo_file_id'] = mid_photo.file_id

    elif message.content_type == 'video':
        # Сохраняем file_id среднего по качеству видео (если есть несколько вариантов качества)
        message_data['video_file_id'] = message.video.file_id

    # Сохраняем сообщение в базе данных, используя функцию save_message
    db.save_message(message_data)


@csrf_exempt
def send_message(request, chat_id):
    if not request.user.is_authenticated:
        return redirect(f'/admin/login/?next={request.path}')

    if request.method == 'POST':
        data = json.loads(request.body)
        message_text = data.get("text")

        if message_text:
            try:
                # Submitting the background task
                mess = executor.submit(send_message_in_background, chat_id, message_text)
                print(mess.result())
                save_telegram_message(mess.result())
                # Get new CSRF token to send back to the client
                new_csrf_token = get_token(request)
                return JsonResponse({"success": True, "csrf_token": new_csrf_token})
            except Exception as e:
                logging.error(f"Failed to submit message: {e}")
                return JsonResponse({"success": False, "error": str(e)}, status=500)
        else:
            return JsonResponse({"success": False, "error": "Empty message"}, status=400)
    else:
        return JsonResponse({"success": False, "error": "Invalid request method"}, status=405)


@csrf_exempt
def toggle_manual_flag(request):
    if not request.user.is_authenticated:
        return redirect(f'/admin/login/?next={request.path}')
    """Изменяет ручной (красный) флажок чата."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body or '{}')
            chat_id = data.get("chat_id")
            manual_flag = data.get("manual_flag", False)
            meta, _ = ChatMeta.objects.get_or_create(chat_id=chat_id, defaults={'chat_name': f"Чат #{chat_id}"})
            meta.manual_flag = manual_flag
            meta.save()
            return JsonResponse({"success": True})
        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)}, status=400)
    else:
        return JsonResponse({"success": False, "error": "Invalid request method"}, status=405)

logger = logging.getLogger(__name__)

def toggle_auto_flag(request):
    if not request.user.is_authenticated:
        return redirect(f'/admin/login/?next={request.path}')
    """Обновляет состояние автофлага (синего чекбокса) для заданного чата."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body or '{}')
            chat_id = data.get("chat_id")
            auto_flag = data.get("auto_flag", False)
            logger.debug(f"toggle_auto_flag: Received for chat_id={chat_id}, auto_flag={auto_flag}")

            # Получаем или создаем запись для чата
            meta, created = ChatMeta.objects.get_or_create(
                chat_id=chat_id,
                defaults={'chat_name': f"Чат #{chat_id}"}
            )
            logger.debug(f"toggle_auto_flag: Retrieved meta={meta} (created={created})")

            meta.auto_flag = auto_flag
            meta.save()
            logger.debug(f"toggle_auto_flag: Saved meta with auto_flag={meta.auto_flag} for chat_id={chat_id}")
            return JsonResponse({"success": True})
        except Exception as e:
            logger.error("toggle_auto_flag: Exception occurred", exc_info=True)
            return JsonResponse({"success": False, "error": str(e)}, status=400)
    else:
        return JsonResponse({"success": False, "error": "Invalid request method"}, status=405)