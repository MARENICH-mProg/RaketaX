from django.contrib import admin
from .models import User, Assistant, TelegramMessage

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'username', 'thread_id', 'status')    # Поля, отображаемые в списке
    search_fields = ('user_id', 'username', 'thread_id', 'status')    # Поля для поиска
    list_filter = ('status', 'username', 'thread_id')                # Фильтры по полям

@admin.register(Assistant)
class AssistantAdmin(admin.ModelAdmin):
    list_display = ('name', 'assistant_id', 'description')  # Отображаем имя, ID и описание ассистента
    search_fields = ('name', 'assistant_id', 'description') # Добавляем возможность поиска по описанию

    def has_add_permission(self, request):
        return False  # Запрещаем добавление новых записей

@admin.register(TelegramMessage)
class TelegramMessageAdmin(admin.ModelAdmin):
    list_display = ('chat_id', 'user_id', 'username', 'message_id', 'message_type', 'timestamp')
    list_filter = ('message_type', 'timestamp','username', 'chat_id', 'user_id')  # Добавляем фильтры
    search_fields = ('username', 'text')
    ordering = ('-timestamp',)
    readonly_fields = ('chat_id', 'user_id', 'username', 'message_id', 'message_type', 'timestamp', 'text', 'photo_file_id', 'video_file_id')

    def has_add_permission(self, request):
        # Запрещаем добавление новых записей вручную
        return False


