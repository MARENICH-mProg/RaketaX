from aiogram import Bot
from aiogram import F, Router, types
from aiogram.enums import ParseMode, ChatAction
from aiogram.client.default import DefaultBotProperties



bot = Bot(token='your token TG bot')  #7324098926:AAECSiuwwvOmgVS0gwQLtPbsO3RResv8TX0 7367084214:AAGshASH5PIyrsBGAlgBsHTaGEX3TKuO0Pc
