import asyncio
import time
from aiogram import Bot, Dispatcher
from aiogram.types import BotCommand
from app.handlers import router
import logging
import sys
from bot_config import bot

# Засекаем время старта
start_time = time.time()

# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,  # Должен быть DEBUG
    format="%(asctime)s - %(levelname)s - %(message)s",
)

async def set_commands(bot: Bot):
    commands = [
        BotCommand(command="/start", description="Перезагрузить"),
        BotCommand(command="/feedback", description="Оставить обратную связь")
    ]
    await bot.set_my_commands(commands)


async def main():
    logging.info("Starting bot setup...")
    async with bot:
        dp = Dispatcher()
        dp.include_router(router)

        try:
            await set_commands(bot)
            logging.info("Starting polling...")
            await dp.start_polling(bot, timeout=300, request_timeout=300)
        except Exception as e:
            logging.error(f"Error during polling: {e}")
        finally:
            await dp.storage.close()
            end_time = time.time()
            logging.info(f"Bot setup time: {end_time - start_time:.2f} seconds")
            logging.info("Shutting down bot...")


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Bot has been manually stopped.")