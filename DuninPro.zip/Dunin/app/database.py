import logging
import sqlite3
from datetime import datetime, timedelta
from typing import Optional,Dict


database = r'C:\Users\User\Desktop\Dunin\myproject\db.sqlite3' #here path to your db
# database = '/Users/matvejgorbunov/PycharmProjects/Dunin/Dunin/myproject/db.sqlite3'

# Предварительное создание пула подключений к базе данных для повторного использования
db_connection = sqlite3.connect(database, check_same_thread=False)
db_connection.row_factory = sqlite3.Row  # Включаем именованные столбцы для результирующих строк


def register_user(user_id: int, thread_id: str, username: Optional[str] = None):
    # Открываем транзакцию с помощью `with db_connection`
    with db_connection:

        try:

            # Проверяем, существует ли пользователь с данным user_id
            user_exists = db_connection.execute('SELECT * FROM myapp_user WHERE user_id = ?', (user_id,)).fetchone()

            if user_exists:
                if user_exists['thread_id'] != thread_id:
                    db_connection.execute('UPDATE myapp_user SET thread_id = ? WHERE user_id = ?', (thread_id, user_id,))
                return dict(user_exists)
            else:
                # Добавляем пользователя в базу данных

                user = db_connection.execute(
                    'INSERT INTO myapp_user (user_id, username, thread_id, status) VALUES (?, ?, ?, ?)',
                    (user_id, username, thread_id, 0)  # Устанавливаем 0 для статуса
                )

                print("Пользователь успешно зарегистрирован.")
                return dict(user)
        except Exception as e:
            logging.exception(e)


def get_user_info(user_id: int) -> Optional[Dict[str, Optional[str]]]:
    try:
        # Получаем информацию о пользователе по user_id
        user_info = db_connection.execute('SELECT * FROM myapp_user WHERE user_id = ?', (user_id,)).fetchone()

        if user_info:
            # Возвращаем результат в виде словаря
            return dict(user_info)
        else:
            print("Пользователь не найден.")
            return None
    except Exception as e:
        logging.exception(e)

def update_status(user_id: int, status: int):
    with db_connection:
        try:
            update = db_connection.execute('UPDATE myapp_user SET status = ? WHERE user_id = ?', (status,user_id,))
        except Exception as e:
            logging.error(e)

def get_assistant_id():
    with db_connection:
        try:
            # Выполняем запрос и получаем результат
            cursor = db_connection.execute('SELECT assistant_id FROM myapp_assistant')
            assistant_id = cursor.fetchone()  # Получаем первую запись

            # Проверяем, есть ли результат
            if assistant_id:
                print(assistant_id[0])  # Выводим assistant_id, если найден
                return assistant_id[0]  # Возвращаем значение assistant_id
            else:
                print("assistant_id не найден")
                return None

        except Exception as e:
            logging.exception(e)
            return None



def save_message(message_data):
    """
    Сохраняем запись о сообщении в таблицу myapp_telegrammessage,
    а затем автоматически ставим auto_flag=TRUE в myapp_chatmeta,
    если сообщение от бота (username == 'OvmSales_bot').
    """

    with db_connection:
        try:
            # 1. Сохраняем новое сообщение в таблицу myapp_telegrammessage
            db_connection.execute('''
                INSERT INTO myapp_telegrammessage
                (chat_id, user_id, username, message_id, text, message_type, timestamp, photo_file_id, video_file_id)
                VALUES (:chat_id, :user_id, :username, :message_id, :text, :message_type, :timestamp, :photo_file_id, :video_file_id)
            ''', message_data)
            db_connection.commit()

            # 2. Проверяем, бот ли это (username == 'OvmSales_bot')
            is_bot = (message_data.get('username') == "OvmSales_bot")
            chat_id = message_data.get('chat_id')

            if not chat_id:
                return  # Если почему-то нет chat_id, нечего обновлять

            if is_bot:
                # Пришло сообщение от бота => auto_flag = TRUE
                # Попробуем обновить запись в myapp_chatmeta
                result = db_connection.execute('''
                    UPDATE myapp_chatmeta
                       SET auto_flag = 1
                     WHERE chat_id = :chat_id
                ''', {'chat_id': chat_id})

                if result.rowcount == 0:
                    # Если строка не обновилась, значит записи нет, создаём
                    db_connection.execute('''
                        INSERT INTO myapp_chatmeta (chat_id, chat_name, auto_flag, manual_flag)
                        VALUES (:chat_id, :chat_name, 1, 0)
                    ''', {
                        'chat_id': chat_id,
                        'chat_name': f"Чат #{chat_id}"
                    })
                db_connection.commit()
            else:
                # Если это пользователь, и вы хотите сбрасывать auto_flag:
                # (Если не надо сбрасывать, закомментируйте или удалите)
                db_connection.execute('''
                    UPDATE myapp_chatmeta
                       SET auto_flag = 1
                     WHERE chat_id = :chat_id
                ''', {'chat_id': chat_id})
                db_connection.commit()

        except Exception as e:
            logging.error(f"Ошибка при сохранении сообщения: {e}", exc_info=True)