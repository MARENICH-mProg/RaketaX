from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton




like = InlineKeyboardButton(text='👍', callback_data='like')
dislike = InlineKeyboardButton(text='👎', callback_data='dislike')
keyboard = InlineKeyboardMarkup(inline_keyboard=[[like, dislike]])


continue_b = InlineKeyboardButton(text='Продолжить общение', callback_data='continue')
continue_keyboard = InlineKeyboardMarkup(inline_keyboard=[[continue_b]])
