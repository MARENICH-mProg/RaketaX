import os
from aiogram.types import InputMediaPhoto, InputMediaVideo, InputFile, FSInputFile
from aiogram.enums import ParseMode, ChatAction


def clear_folder(folder_path, substring=None):
    try:
        # Получаем список всех файлов и папок в указанной папке
        files = os.listdir(folder_path)
        # Проходимся по каждому файлу в списке
        for file in files:
            # Формируем путь к файлу
            file_path = os.path.join(folder_path, file)
            # Проверяем, является ли текущий элемент файлом
            if os.path.isfile(file_path):
                # Проверяем, содержится ли подстрока в названии файла, если подстрока указана
                if str(substring) is None or str(substring) in file:
                    # Если это файл и он содержит подстроку, удаляем его
                    os.remove(file_path)

        print("Папка очищена")
    except Exception as e:
        print("Произошла ошибка при очистке папки:", str(e))


def check_files_in_directory(directory_path, variable):
    # Проверяем, существует ли указанный путь
    if not os.path.exists(directory_path):
        print(f"Путь {directory_path} не существует.")
        return []

    # Список файлов, содержащих переменную в названии
    matching_files = []

    # Проходимся по всем файлам в указанной директории
    for filename in os.listdir(directory_path):
        # Проверяем, если переменная содержится в названии файла
        if str(variable) in filename:
            matching_files.append(filename)

    return matching_files


