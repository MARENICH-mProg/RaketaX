import asyncio
from datetime import datetime
import re
import sys
import logging
import os

import aiofiles

from asgiref.sync import sync_to_async
from aiogram.utils.formatting import Text, Bold, Italic
from pydantic.v1.typing import test_type
from app.functions import check_files_in_directory, clear_folder
import app.database as db
from aiogram import F, Router, types
from aiogram.enums import ParseMode, ChatAction
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    FSInputFile,
    URLInputFile,
    ReplyKeyboardRemove,
    ContentType, CallbackQuery
)
from aiogram import types
from aiogram.types import Update

from bot_config import bot

from openai import OpenAI, default_headers

import app.keyboards as kb

from aiogram.utils.media_group import MediaGroupBuilder
from aiogram.types import InputMediaPhoto, InputMediaVideo, InputFile
from aiogram.utils.chat_action import ChatActionSender
from app.album_middleware import AlbumMiddleware

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

client = OpenAI(api_key='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')

router = Router()
router.message.middleware(AlbumMiddleware())

markdown_prompt = (
    " Пожалуйста, используй _только_ следующие правила форматирования в MarkdownV2 для структурирования ответа:\n"
    " - *Жирный шрифт*: Для выделения важных слов используй одну звёздочку (`*`) с обеих сторон текста, например: *жирный текст*.\n"
    " - __Подчёркивание__: Чтобы подчеркнуть важные мысли, используй двойное подчёркивание (`__`) с двух сторон текста, например: __подчёркнутый текст__.\n"
    " Если нужно использовать дефис, то используй только один тип `-`\n"
    " - Избегай использования HTML-тегов, таких как `<b>`, `<i>`, `<u>`, `<span>`, так как они не поддерживаются в MarkdownV2.\n"
    " Форматируй текст логически, внимательно следя за правильным применением MarkdownV2.\n"
    " Если тебе отправили непонятный запрос, никогда не пиши про форматирование — уточни, что хотел спросить пользователь.\n"
    " Никогда не давай в ответе настройки нашего форматирования! ВООБЩЕ НИКОГДА НЕ ГОВОРИ О ТВОЕМ ФОРМАТИРОВАНИИ\n"
    " Будь более человечным в своих ответах"
)

# Предкомпилированное регулярное выражение для clean_response_text
_CLEAN_RESPONSE_RE = re.compile(r'【\d+:\d+†.*?】')


async def save_telegram_message(message):
    message_data = {
        'chat_id': message.chat.id,
        'user_id': message.from_user.id,
        'username': message.from_user.username,
        'message_id': message.message_id,
        'text': message.text if message.content_type == 'text' else None,
        'message_type': message.content_type,
        'timestamp': message.date,
        'photo_file_id': None,
        'video_file_id': None,
    }

    if message.content_type == 'photo':
        mid_photo = message.photo[len(message.photo) // 2]
        message_data['photo_file_id'] = mid_photo.file_id
    elif message.content_type == 'video':
        message_data['video_file_id'] = message.video.file_id

    await asyncio.to_thread(db.save_message, message_data)


def clean_response_text(text: str) -> str:
    cleaned_text = _CLEAN_RESPONSE_RE.sub('', text)
    logging.info(f"Очищенный текст: {cleaned_text}")
    return cleaned_text


def convert_to_markdown_v2(text):
    special_characters = r'([()~`#+={}.!])'
    link_pattern = r'(\[[^\]]+\]\(https?://[^\s]+\))'
    parts = re.split(link_pattern, text)
    formatted_parts = []
    for part in parts:
        if re.match(link_pattern, part):
            part = re.sub(r'(?<=\[)([^\]]*?)(?=\])', lambda m: re.sub(r'([.])', r'\\\1', m.group(0)), part)
            formatted_parts.append(part)
        else:
            part = re.sub(special_characters, r'\\\1', part)
            part = re.sub(r'(?<!\|)\|(?!\|)', r'\\|', part)
            part = part.replace("-", r"\-")
            formatted_parts.append(part)
    return "".join(formatted_parts)


async def start_assistant(client, thread_id):
    logging.info(f"Запуск ассистента для треда {thread_id}")
    assistant_id = await asyncio.to_thread(db.get_assistant_id)
    return client.beta.threads.runs.create(thread_id=thread_id, assistant_id=assistant_id)


async def process_run(client, thread_id, run, message_text, user_id):
    timeout = 60  # максимальный таймаут в секундах
    start_time = asyncio.get_event_loop().time()
    while True:
        run_status = run.status
        logging.info(f"Статус выполнения: {run_status}")
        if run_status == 'completed':
            logging.info("Выполнение завершено")
            await asyncio.to_thread(db.update_status, user_id=user_id, status=0)
            break
        elif run_status in ['in_progress', 'queued']:
            logging.info(f"Статус {run_status}, ожидаем 3 секунды")
            await asyncio.sleep(3)
            run = await asyncio.to_thread(client.beta.threads.runs.retrieve, thread_id=thread_id, run_id=run.id)
        elif run_status == 'failed':
            logging.warning("Выполнение не удалось, перезапускаем ассистента")
            await asyncio.sleep(3)
            run = await start_assistant(client, thread_id)
        elif run_status == 'requires_action':
            logging.info("Требуется действие, отправляем результаты инструмента")
            required_action = run.required_action
            submit_tool_outputs = required_action.submit_tool_outputs
            tool_call_id = submit_tool_outputs.tool_calls[0].id
            client.beta.threads.runs.submit_tool_outputs(
                thread_id=thread_id,
                run_id=run.id,
                tool_outputs=[{"tool_call_id": tool_call_id, "output": "true"}]
            )
            await asyncio.sleep(3)
            run = await asyncio.to_thread(client.beta.threads.runs.retrieve, thread_id=thread_id, run_id=run.id)
        else:
            await message_text.answer('Произошла ошибка при выполнении запроса к ИИ.')
            await asyncio.to_thread(db.update_status, user_id=user_id, status=0)
            logging.error(f"Неизвестный статус выполнения: {run_status}")
            return None
        if asyncio.get_event_loop().time() - start_time > timeout:
            logging.error("Превышено время ожидания ответа ИИ")
            await message_text.answer('Время ожидания истекло, попробуйте снова.')
            await asyncio.to_thread(db.update_status, user_id=user_id, status=0)
            return None
    return run


def escape_markdown_v2(text):
    special_characters = r'[_*[\]()~`>#+\-=|{}.!]'
    return re.sub(special_characters, r'\\\g<0>', text)


class Feedback(StatesGroup):
    get_feed = State()


@router.message(CommandStart())
async def start_command(message: Message):
    if message.chat.type == "private":
        empty_thread = client.beta.threads.create()
        await asyncio.to_thread(db.update_status, user_id=message.from_user.id, status=0)
        user = await asyncio.to_thread(db.register_user, user_id=message.from_user.id, username=message.from_user.username, thread_id=empty_thread.id)
        await save_telegram_message(message)
        first_message = await message.answer('Здравствуйте!\nРады Вас приветствовать в компании Торговый Дом «Овоще-Молочный», меня зовут Олег.\nПодскажите пожалуйста, как я могу к Вам обращаться и какой у вас вопрос?')
        await save_telegram_message(first_message)
        text_for_thread = 'Здравствуйте!\nРады Вас приветствовать в компании Торговый Дом «Овоще-Молочный», меня зовут Олег.\nПодскажите пожалуйста, как я могу к Вам обращаться и какой у вас вопрос?'
        logging.info(f'Создан новый Thread: {empty_thread}')
        client.beta.threads.messages.create(
            empty_thread.id,
            role="assistant",
            content=text_for_thread,
        )


@router.message(Command('feedback'))
async def feedback(message: Message, state: FSMContext):
    if message.chat.type == "private":
        mess = await message.answer('Оставьте обратную связь.\n\nЕсли вы передумали, нажмите на кнопку ниже.', reply_markup=kb.continue_keyboard)
        await save_telegram_message(mess)
        await state.set_state(Feedback.get_feed)


@router.message(StateFilter(Feedback.get_feed))
async def get_feed(message: Message, state: FSMContext):
    if message.chat.type == "private":
        mess = await message.answer('Спасибо за обратную связь! Можем продолжить общение!')
        await save_telegram_message(mess)
        await state.clear()
        if message.from_user.username is not None:
            await message.bot.send_message(-4664345383, message.text + f'\n\nОбратная связь от пользователя @{message.from_user.username}')
        else:
            await message.bot.send_message(-4664345383, message.text + f'\n\nОбратная связь от пользователя {message.from_user.id}')


@router.callback_query(lambda query: query.data == 'continue')
async def continue_handler(query: CallbackQuery, state: FSMContext):
    if query.message.chat.type == "private":
        await asyncio.to_thread(db.update_status, user_id=query.from_user.id, status=0)
        await state.clear()
        empty_thread = client.beta.threads.create()
        first_message = await query.message.answer('Здравствуйте!\nРады Вас приветствовать в компании Торговый Дом «Овоще-Молочный», меня зовут Олег.\nПодскажите пожалуйста, как я могу к Вам обращаться и какой у вас вопрос?')
        text_for_thread = 'Здравствуйте!\nРады Вас приветствовать в компании Торговый Дом «Овоще-Молочный», меня зовут Олег.\nПодскажите пожалуйста, как я могу к Вам обращаться и какой у вас вопрос?'
        logging.info(f'Создан новый Thread: {empty_thread}')
        client.beta.threads.messages.create(
            empty_thread.id,
            role="assistant",
            content=text_for_thread,
        )
        await query.message.delete()


@router.message(F.document | F.video | F.video_note | F.animation)
async def det_document(message: Message):
    if message.chat.type == "private":
        await message.answer('Я не могу прочитать такое! Отправь мне текст, фото или аудио, чтобы я мог тебе помочь!')


@router.message(F.text != None)
async def get_question(message: Message):

    if message.chat.type == "private":
        try:
            await save_telegram_message(message)
            user_data = await asyncio.to_thread(db.get_user_info, message.from_user.id)
            if user_data['status'] != 1:
                await asyncio.to_thread(db.update_status, message.from_user.id, 1)
                thread_id = user_data['thread_id']
                logging.info(f"Получено сообщение от пользователя {message.from_user.id}: {message.text}")
                async with ChatActionSender.typing(bot=bot, chat_id=message.chat.id):
                    processing_message = await message.answer("💬")
                    await save_telegram_message(processing_message)
                    logging.info(f"Добавлено сообщение пользователя в тред {thread_id}")
                    client.beta.threads.messages.create(
                        thread_id,
                        role="user",
                        content=message.text + markdown_prompt,
                    )
                    run = await start_assistant(client, thread_id)
                    run = await process_run(client, thread_id, run, message, message.from_user.id)
                    if run is None:
                        return
                    thread_messages = client.beta.threads.messages.list(thread_id=thread_id)
                    response_message = thread_messages.data[0].content[0].text.value
                    logging.info(f"Оригинальный текст: {response_message}")
                    response_message = clean_response_text(response_message)
                    formatted_text = convert_to_markdown_v2(response_message)
                    logging.info(f"Форматированный текст: {formatted_text}")
                    mess = await message.answer(formatted_text, parse_mode='MarkdownV2', reply_markup=kb.keyboard)
                    await save_telegram_message(mess)
                    await processing_message.delete()
            else:
                mess = await message.answer('Подожди, пока я обработаю твой предыдущий запрос!')
                await save_telegram_message(mess)
                await message.delete()
                await asyncio.sleep(3)
                await mess.delete()
        except Exception as e:
            logging.error(e)
            await asyncio.to_thread(db.update_status, user_id=message.from_user.id, status=0)


@router.message(F.voice != None)
async def voice_handler(message: Message):
    if message.chat.type == "private":
        try:
            user_data = await asyncio.to_thread(db.get_user_info, message.from_user.id)
            if user_data['status'] != 1:
                await asyncio.to_thread(db.update_status, message.from_user.id, 1)
                thread_id = user_data['thread_id']
                logging.info(f"Получено голосовое сообщение от пользователя {message.from_user.id}")
                processing_message = await message.answer("💬")
                file_id = message.voice.file_id
                file = await bot.get_file(file_id)
                file_path = f"voice_message_{message.from_user.id}.ogg"
                await bot.download_file(file.file_path, file_path)
                try:
                    async with aiofiles.open(file_path, "rb") as audio_file:
                        content = await audio_file.read()
                    transcript = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=content
                    )
                    user_message = transcript.text
                    logging.info(f"Транскрибировано голосовое сообщение от пользователя {message.from_user.id}: {user_message}")
                    client.beta.threads.messages.create(
                        thread_id,
                        role="user",
                        content=user_message + markdown_prompt,
                    )
                    run = await start_assistant(client, thread_id)
                    run = await process_run(client, thread_id, run, message, message.from_user.id)
                    if run is None:
                        return
                    thread_messages = client.beta.threads.messages.list(thread_id=thread_id)
                    response_message = thread_messages.data[0].content[0].text.value
                    response_message = clean_response_text(response_message)
                    formatted_text = convert_to_markdown_v2(response_message)
                    mess = await message.answer(formatted_text, parse_mode='MarkdownV2', reply_markup=kb.keyboard)
                    await processing_message.delete()
                except Exception as e:
                    logging.error(f"Ошибка при транскрипции голосового сообщения от пользователя {message.from_user.id}: {e}")
                    await message.answer(f"Произошла ошибка при транскрипции: {e}")
                finally:
                    try:
                        os.remove(file_path)
                    except Exception as err:
                        logging.error(f"Не удалось удалить файл {file_path}: {err}")
            else:
                mess = await message.answer('Подожди, пока я обработаю твой предыдущий запрос!')
                await message.delete()
                await asyncio.sleep(3)
                await mess.delete()
        except Exception as e:
            logging.error(e)
            await asyncio.to_thread(db.update_status, user_id=message.from_user.id, status=0)


@router.message(F.photo != None)
async def photo_handler(message: Message, album: list = None):
    if message.chat.type == "private":
        try:
            await save_telegram_message(message)
            user_data = await asyncio.to_thread(db.get_user_info, message.from_user.id)
            if user_data['status'] != 1:
                await asyncio.to_thread(db.update_status, message.from_user.id, 1)
                thread_id = user_data['thread_id']
                logging.info(f"Получено сообщение с фотографией от пользователя {message.from_user.id}")
                processing_message = await message.answer("💬")
                await save_telegram_message(processing_message)
                if album:
                    folder_path = "/root/Dunin/Media"
                    if check_files_in_directory(folder_path, variable=message.from_user.id) != []:
                        clear_folder(folder_path, message.from_user.id)
                    media_files = []
                    for i in album:
                        if i.photo is not None:
                            media = i.photo[-1].file_id
                            file_info = await message.bot.get_file(media)
                            downloaded_file = await message.bot.download_file(file_info.file_path)
                            save_path = os.path.join(folder_path, f'{message.chat.id}+{media}.jpg')
                            async with aiofiles.open(save_path, 'wb') as new_file:
                                await new_file.write(downloaded_file.getvalue())
                            async with aiofiles.open(save_path, "rb") as image_file:
                                uploaded_file = client.files.create(
                                    file=await image_file.read(),
                                    purpose="vision"
                                )
                            media_files.append({"file_id": uploaded_file.id})
                    if album[0].caption is not None:
                        combined_message = album[0].caption + markdown_prompt
                    else:
                        combined_message = 'Расскажи, что изображено на фото.' + markdown_prompt

                    client.beta.threads.messages.create(
                        thread_id,
                        role="user",
                        content=[
                            {"type": "text", "text": combined_message},
                            *[
                                {"type": "image_file", "image_file": {"file_id": file["file_id"]}}
                                for file in media_files
                            ]
                        ]
                    )
                    logging.info(f"Добавлено сообщение с изображением в тред {thread_id}")
                    run = await start_assistant(client, thread_id)
                    logging.info(f"Запущен ассистент с ID выполнения {run.id} для треда {thread_id}")
                    run = await process_run(client, thread_id, run, message, message.from_user.id)
                    if run is None:
                        return
                    thread_messages = client.beta.threads.messages.list(thread_id=thread_id)
                    response_message = thread_messages.data[0].content[0].text.value
                    response_message = clean_response_text(response_message)
                    formatted_text = convert_to_markdown_v2(response_message)
                    mess = await message.answer(formatted_text, parse_mode='MarkdownV2', reply_markup=kb.keyboard)
                    await processing_message.delete()
                    await save_telegram_message(mess)
            else:
                mess = await message.answer('Подожди, пока я обработаю твой предыдущий запрос!')
                await save_telegram_message(mess)
                await message.delete()
                await asyncio.sleep(3)
                await mess.delete()
        except Exception as e:
            logging.error(e)
            await asyncio.to_thread(db.update_status, user_id=message.from_user.id, status=0)


@router.callback_query(lambda query: query.data == 'like')
async def like_handler(query: CallbackQuery):
    if query.message.chat.type == "private":
        formatted_text = query.message.text
        entities = query.message.entities
        await query.message.edit_text(
            f'{formatted_text}\n\nСпасибо за оценку! Можем продолжить общение!',
            entities=entities
        )
        if query.from_user.username:
            message_i = await query.bot.forward_message(-4664345383, query.message.chat.id, query.message.message_id)
            await message_i.reply(
                f'Ответ Понравился ✅ @{query.from_user.username}',
            )
        else:
            message_i = await query.bot.forward_message(-4664345383, query.message.chat.id, query.message.message_id)
            await message_i.reply(
                f'Ответ Понравился ✅ {query.from_user.id}',
            )


@router.callback_query(lambda query: query.data == 'dislike')
async def dislike_handler(query: CallbackQuery):
    if query.message.chat.type == "private":
        formatted_text = query.message.text
        entities = query.message.entities
        await query.message.edit_text(
            f'{formatted_text}\n\nСпасибо за оценку! Можем продолжить общение!',
            entities=entities
        )
        if query.from_user.username:
            message_i = await query.bot.forward_message(-4664345383, query.message.chat.id, query.message.message_id)
            await message_i.reply(
                f'Ответ Не Понравился ❌ @{query.from_user.username}',
            )
        else:
            message_i = await query.bot.forward_message(-4664345383, query.message.chat.id, query.message.message_id)
            await message_i.reply(
                f'Ответ Не Понравился ❌ {query.from_user.id}',
            )
